import React, { useState } from 'react';
import { CubeIcon } from './Icons';
import CGMinerEmulator from './emulators/CGMinerEmulator';
import GMinerEmulator from './emulators/GMinerEmulator';
import MultiMinerEmulator from './emulators/MultiMinerEmulator';

type EmulatorView = 'cgminer' | 'gminer' | 'multiminer';

const EmulatorsPage: React.FC = () => {
    const [activeView, setActiveView] = useState<EmulatorView>('cgminer');
    
    const renderActiveView = () => {
        switch(activeView) {
            case 'cgminer': return <CGMinerEmulator />;
            case 'gminer': return <GMinerEmulator />;
            case 'multiminer': return <MultiMinerEmulator />;
            default: return <CGMinerEmulator />;
        }
    }

    return (
        <div className="max-w-7xl mx-auto space-y-6">
            <div className="flex items-center space-x-4">
                <CubeIcon className="w-10 h-10 text-primary" />
                <div>
                    <h1 className="text-3xl font-bold">Mining Emulators</h1>
                    <p className="text-light-text-secondary dark:text-dark-text-secondary">
                        Simulate popular miners for educational and UI testing purposes. No real mining occurs.
                    </p>
                </div>
            </div>

            <div className="border-b border-light-border dark:border-dark-border">
                <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                    <TabButton name="CGMiner" active={activeView === 'cgminer'} onClick={() => setActiveView('cgminer')} />
                    <TabButton name="GMiner" active={activeView === 'gminer'} onClick={() => setActiveView('gminer')} />
                    <TabButton name="MultiMiner" active={activeView === 'multiminer'} onClick={() => setActiveView('multiminer')} />
                </nav>
            </div>
            
            <div className="mt-4">
                {renderActiveView()}
            </div>
        </div>
    );
};

const TabButton: React.FC<{name: string, active: boolean, onClick: () => void}> = ({ name, active, onClick }) => {
    return (
        <button
            onClick={onClick}
            className={`${
                active
                ? 'border-primary text-primary'
                : 'border-transparent text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-gray-500'
            } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}
        >
            {name}
        </button>
    )
}


export default EmulatorsPage;