import React, { useContext, useState, useEffect } from 'react';
import { AppContext } from '../contexts/AppContext';
import StatCard from './StatCard';
import { SidebarWalletIcon, ArrowUpRightIcon, ArrowDownLeftIcon, ArrowTopRightOnSquareIcon, ShieldCheckIcon, KeyIcon } from './Icons';
import { Transaction } from '../types';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import SendModal from './SendModal';
import ReceiveModal from './ReceiveModal';
import * as backendAPI from '../services/electronAPI';
import ViewRecoveryPhraseModal from './ViewRecoveryPhraseModal';


dayjs.extend(relativeTime);

const ExplorerLink: React.FC<{ coinId: string; ticker: string, txHash: string }> = ({ coinId, ticker, txHash }) => {
    const [url, setUrl] = useState('#');

    useEffect(() => {
        backendAPI.getExplorerLink({ id: coinId, ticker } as any, txHash).then(setUrl);
    }, [coinId, ticker, txHash]);

    return (
        <a href={url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-primary hover:underline text-xs">
            {txHash.substring(0, 8)}...{txHash.substring(txHash.length - 8)}
            <ArrowTopRightOnSquareIcon className="w-3 h-3 ml-1" />
        </a>
    )
}

const TransactionRow: React.FC<{ tx: Transaction }> = ({ tx }) => {
    const { payoutCoin } = useContext(AppContext);
    const isSend = tx.type === 'send';
    
    const statusClasses = {
        completed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
        confirming: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300 animate-pulse',
        failed: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    }

    return (
        <tr className="hover:bg-light-bg dark:hover:bg-dark-bg">
            <td className="px-4 py-3">
                <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${isSend ? 'bg-red-100 dark:bg-red-900' : 'bg-green-100 dark:bg-green-900'}`}>
                        {isSend ? <ArrowUpRightIcon className="w-5 h-5 text-red-500"/> : <ArrowDownLeftIcon className="w-5 h-5 text-green-500"/>}
                    </div>
                    <div>
                        <p className="font-medium capitalize">{tx.type}</p>
                        <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary">{dayjs(tx.timestamp).fromNow()}</p>
                    </div>
                </div>
            </td>
            <td className="px-4 py-3">
                 <span className={`px-2 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClasses[tx.status]}`}>
                    {tx.status}
                </span>
            </td>
            <td className="px-4 py-3 font-mono text-right">
                <p className={`font-semibold ${isSend ? 'text-red-500' : 'text-green-500'}`}>{isSend ? '-' : '+'}{tx.amount.toFixed(6)} {payoutCoin.ticker}</p>
                {tx.hash && tx.status !== 'confirming' && (
                    <ExplorerLink coinId={payoutCoin.id} ticker={payoutCoin.ticker} txHash={tx.hash} />
                )}
            </td>
        </tr>
    );
}

export const WalletPage: React.FC = () => {
  const { currentUser, payoutCoin, walletBalance, transactions, initiateAction } = useContext(AppContext);
  const [isSendModalOpen, setIsSendModalOpen] = useState(false);
  const [isReceiveModalOpen, setIsReceiveModalOpen] = useState(false);
  const [isRecoveryModalOpen, setIsRecoveryModalOpen] = useState(false);
  
  const balanceUSD = (walletBalance * (payoutCoin.price || 0)).toFixed(2);

  return (
    <>
    <SendModal isOpen={isSendModalOpen} onClose={() => setIsSendModalOpen(false)} />
    <ReceiveModal isOpen={isReceiveModalOpen} onClose={() => setIsReceiveModalOpen(false)} />
    <ViewRecoveryPhraseModal isOpen={isRecoveryModalOpen} onClose={() => setIsRecoveryModalOpen(false)} />
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center space-x-4">
        <SidebarWalletIcon className="w-10 h-10 text-primary" />
        <div>
            <h1 className="text-3xl font-bold">Wallet</h1>
            <p className="text-light-text-secondary dark:text-dark-text-secondary">Manage your funds securely.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <StatCard title={`Total Balance (${payoutCoin.ticker})`}>
              <p className="text-3xl font-bold">{walletBalance.toFixed(6)}</p>
              <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">~${balanceUSD} USD</p>
          </StatCard>
          <div className="bg-light-card dark:bg-dark-card p-6 rounded-lg shadow-lg flex flex-col justify-center space-y-3">
              <div className="flex items-center justify-between">
                <p className="font-medium text-sm flex items-center"><ShieldCheckIcon className="w-5 h-5 mr-2 text-green-500"/> Your keys, your crypto.</p>
                <button onClick={() => setIsRecoveryModalOpen(true)} className="text-sm font-semibold text-primary hover:underline flex items-center">
                    <KeyIcon className="w-4 h-4 mr-1" /> View Recovery Phrase
                </button>
              </div>
              <div className="flex space-x-3">
                <button onClick={() => setIsSendModalOpen(true)} className="flex-1 btn-primary bg-secondary hover:bg-blue-600 focus:ring-blue-500">Send</button>
                <button onClick={() => setIsReceiveModalOpen(true)} className="flex-1 btn-primary">Receive</button>
              </div>
          </div>
      </div>
      
      <div className="bg-light-card dark:bg-dark-card rounded-lg shadow-lg">
           <h2 className="text-xl font-semibold p-4 border-b border-light-border dark:border-dark-border">Transaction History</h2>
           <div className="overflow-x-auto">
               <table className="min-w-full">
                   <thead className="bg-light-bg dark:bg-dark-bg">
                       <tr>
                           <th className="px-4 py-2 text-left text-xs font-medium text-light-text-secondary dark:text-dark-text-secondary uppercase">Details</th>
                           <th className="px-4 py-2 text-left text-xs font-medium text-light-text-secondary dark:text-dark-text-secondary uppercase">Status</th>
                           <th className="px-4 py-2 text-right text-xs font-medium text-light-text-secondary dark:text-dark-text-secondary uppercase">Amount</th>
                       </tr>
                   </thead>
                   <tbody className="divide-y divide-light-border dark:divide-dark-border">
                      {transactions.length > 0 ? (
                           transactions.map(tx => <TransactionRow key={tx.id} tx={tx} />)
                      ) : (
                          <tr>
                              <td colSpan={3} className="text-center py-12 text-sm text-light-text-secondary dark:text-dark-text-secondary">
                                  No transactions yet.
                              </td>
                          </tr>
                      )}
                   </tbody>
               </table>
           </div>
      </div>

    </div>
    </>
  );
};
