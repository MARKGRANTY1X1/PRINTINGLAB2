
import React, { useRef, useEffect } from 'react';
import { EmulatorLog, EmulatorStatusUpdate, DeviceStats } from '../../types';
import dayjs from 'dayjs';

interface TerminalOutputProps {
  logs: EmulatorLog[];
  variant: 'cgminer' | 'gminer';
}

const formatHashrate = (hashrate: number, unit: 'M' | 'G' | 'T' | 'auto' = 'auto'): string => {
    let rate = hashrate;
    let u = 'M';
    if (unit === 'auto') {
        if (rate > 1000) { rate /= 1000; u = 'G'; }
        if (rate > 1000) { rate /= 1000; u = 'T'; }
    } else {
        if (unit === 'G') rate /= 1000;
        if (unit === 'T') rate /= (1000 * 1000);
        u = unit;
    }
    return `${rate.toFixed(2)} ${u}H/s`;
};

const CgminerStatus: React.FC<{status: EmulatorStatusUpdate}> = ({ status }) => {
    const lastShare = status.lastShareTime ? dayjs(status.lastShareTime).fromNow() : 'never';
    return (
        <div className="text-xs">
            <div className="text-yellow-300">
                <span>{`[ ${dayjs().format('YYYY-MM-DD HH:mm:ss')} ]`}</span>
                <span className="ml-4">{status.devices.length} ASIC(s) - {formatHashrate(status.totalHashrate, 'auto')}</span>
            </div>
            <div className="text-gray-300">
                <span>Accepted: {status.acceptedShares}</span>
                <span className="ml-4">Rejected: {status.rejectedShares}</span>
                <span className="ml-4">Last Share: {lastShare}</span>
            </div>
        </div>
    );
}

const GminerStatus: React.FC<{status: EmulatorStatusUpdate}> = ({ status }) => (
    <div className="text-xs">
        <span className="text-gray-400">{`[${dayjs().format('HH:mm:ss')}]`}</span>
        <span className="text-cyan-400 font-bold"> Total Speed: {formatHashrate(status.totalHashrate)}</span>
        <span className="text-yellow-400"> Power: {status.totalPower}W</span>
        <span className="text-green-400"> A:{status.acceptedShares}</span>
        <span className="text-red-500"> R:{status.rejectedShares}</span>
        <div className="pl-4">
        {status.devices.map((dev, i) => (
            <span key={dev.id} className="mr-4">
                {`GPU${i}: ${formatHashrate(dev.hashrate)} T:${dev.temperature.toFixed(0)}C F:${dev.fanSpeed}% P:${dev.power}W`}
            </span>
        ))}
        </div>
    </div>
);


const TerminalOutput: React.FC<TerminalOutputProps> = ({ logs, variant }) => {
  const endOfLogsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endOfLogsRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className="h-96 bg-gray-900 text-gray-300 font-mono text-xs rounded-t-md p-4 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800">
      {logs.map((log, index) => {
        let content;
        switch (log.type) {
          case 'STATUS':
            content = variant === 'cgminer' 
                ? <CgminerStatus status={log.content as EmulatorStatusUpdate}/> 
                : <GminerStatus status={log.content as EmulatorStatusUpdate}/>;
            break;
          case 'SHARE_FOUND':
            content = <span className="text-green-400">{`[${log.timestamp}] [SUCCESS] ${log.content}`}</span>;
            break;
          case 'ERROR':
            content = <span className="text-red-400">{`[${log.timestamp}] [ERROR] ${log.content}`}</span>;
            break;
          case 'DEV_FEE':
            content = <span className="text-yellow-400">{`[${log.timestamp}] ${log.content}`}</span>
            break;
          case 'INFO':
            content = <pre className="whitespace-pre-wrap">{log.content}</pre>;
            break;
          default:
            content = <span>{log.content}</span>;
        }
        return <div key={index} className="mb-1">{content}</div>;
      })}
      <div ref={endOfLogsRef} />
    </div>
  );
};

export default TerminalOutput;
