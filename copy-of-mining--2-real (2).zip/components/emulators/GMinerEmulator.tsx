
import React, { useState, useEffect, useCallback } from 'react';
import * as backendAPI from '../../services/electronAPI';
import { EmulatorLog } from '../../types';
import TerminalOutput from './TerminalOutput';
import dayjs from 'dayjs';

const GMinerEmulator: React.FC = () => {
    const [isRunning, setIsRunning] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [logs, setLogs] = useState<EmulatorLog[]>([]);

    const addLog = useCallback((type: EmulatorLog['type'], content: any) => {
         setLogs(prev => [...prev, { timestamp: dayjs().format('HH:mm:ss'), type, content }]);
    }, []);

     const processUpdate = useCallback((data: any) => {
        addLog(data.type, data.content);
    }, [addLog]);

    useEffect(() => {
        const removeListener = backendAPI.onEmulatorUpdate('gminer', processUpdate);
        return () => removeListener();
    }, [processUpdate]);

    const handleStart = async () => {
        setIsLoading(true);
        setLogs([]);
        addLog('INFO', "Simulating GPU detection...");
        setTimeout(async () => {
             const success = await backendAPI.startEmulator('gminer');
            if (success) {
                setIsRunning(true);
            } else {
                addLog('ERROR', 'Failed to start GMiner emulator.');
            }
            setIsLoading(false);
        }, 1000);
    };

    const handleStop = async () => {
        setIsLoading(true);
        await backendAPI.stopEmulator('gminer');
        setIsRunning(false);
        setIsLoading(false);
    };

    return (
        <div className="bg-light-card dark:bg-dark-card p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">GMiner CUDA Emulator</h2>
                <button
                    onClick={isRunning ? handleStop : handleStart}
                    disabled={isLoading}
                    className={`px-4 py-2 font-bold rounded-md transition-colors w-32 ${
                        isRunning 
                        ? 'bg-red-600 hover:bg-red-700 text-white' 
                        : 'bg-primary hover:bg-primary-focus text-primary-content'
                    } disabled:bg-gray-500`}
                >
                    {isLoading ? '...' : isRunning ? 'Stop' : 'Start'}
                </button>
            </div>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
                A GPU-focused simulation, including periodic developer fee messages.
            </p>
            <TerminalOutput logs={logs} variant="gminer" />
        </div>
    );
};

export default GMinerEmulator;
