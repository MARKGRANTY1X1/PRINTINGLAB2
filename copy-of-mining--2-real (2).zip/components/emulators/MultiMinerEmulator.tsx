import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { BfgminerInstance, DeviceStats } from '../../types';
import { PlusCircleIcon, TrashIcon, HashtagIcon, CpuChipIcon, ClockIcon } from '../Icons';
import { useToast } from '../../contexts/ToastContext';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';

dayjs.extend(duration);

const API_BASE_URL = 'http://localhost:3001/api/bfgminer';

const formatHashrate = (hashrate: number) => {
  if (hashrate < 1000) return `${hashrate.toFixed(2)} MH/s`;
  if (hashrate < 1000 * 1000) return `${(hashrate / 1000).toFixed(2)} GH/s`;
  return `${(hashrate / (1000 * 1000)).toFixed(2)} TH/s`;
};

const DeviceStat: React.FC<{ device: DeviceStats }> = ({ device }) => (
    <div className="bg-light-bg dark:bg-dark-bg p-2 rounded-md text-xs flex justify-between items-center">
        <span className="font-bold w-1/3 truncate">{device.name}</span>
        <span className="w-1/4 text-center">{formatHashrate(device.hashrate)}</span>
        <span className="w-1/4 text-center">{device.temperature.toFixed(1)}°C</span>
        <span className="w-1/4 text-right">{device.power}W</span>
    </div>
)

const MultiMinerEmulator: React.FC = () => {
    const [miners, setMiners] = useState<BfgminerInstance[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const { addToast } = useToast();

    const fetchMiners = useCallback(async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}/list`);
            setMiners(response.data);
        } catch (error) {
            console.error('Failed to fetch miner list', error);
        }
    }, []);

    useEffect(() => {
        fetchMiners();
        const interval = setInterval(fetchMiners, 5000); // Poll every 5 seconds
        return () => clearInterval(interval);
    }, [fetchMiners]);

    const handleAddMiner = async () => {
        setIsLoading(true);
        try {
            await axios.post(`${API_BASE_URL}/create`);
            addToast('New BFGMiner instance started.', 'success');
            fetchMiners();
        } catch (error) {
            addToast('Failed to start a new miner instance.', 'error');
        }
        setIsLoading(false);
    };

    const handleRemoveMiner = async (id: string) => {
        try {
            await axios.post(`${API_BASE_URL}/stop/${id}`);
            addToast(`Stopped miner instance ${id}.`, 'info');
            setMiners(prev => prev.filter(m => m.id !== id));
        } catch (error) {
            addToast('Failed to stop miner instance.', 'error');
        }
    };

    return (
        <div className="bg-light-card dark:bg-dark-card p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <div>
                    <h2 className="text-xl font-semibold">MultiMiner Dashboard (BFGMiner API)</h2>
                    <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">
                        A GUI for the BFGMiner emulator. Add or remove simulated miners below.
                    </p>
                </div>
                <button
                    onClick={handleAddMiner}
                    disabled={isLoading}
                    className="flex items-center px-4 py-2 bg-primary text-primary-content rounded-md hover:bg-primary-focus transition-colors disabled:bg-gray-500"
                >
                    <PlusCircleIcon className="w-5 h-5 mr-2" />
                    Add Miner
                </button>
            </div>
            
            <div className="space-y-4">
                {miners.length === 0 ? (
                    <div className="text-center py-12 text-light-text-secondary dark:text-dark-text-secondary">
                        <p>No active miner instances.</p>
                        <p className="text-sm">Click "Add Miner" to start a new simulation.</p>
                    </div>
                ) : (
                    miners.map(miner => (
                        <div key={miner.id} className="border border-light-border dark:border-dark-border rounded-lg p-4">
                            <div className="flex justify-between items-center mb-3">
                                <h3 className="font-bold font-mono text-primary">{miner.id}</h3>
                                <button onClick={() => handleRemoveMiner(miner.id)} className="text-red-500 hover:text-red-700 p-1">
                                    <TrashIcon className="w-5 h-5"/>
                                </button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-3">
                                <div className="flex items-center space-x-2"><HashtagIcon className="w-5 h-5 text-gray-400"/><span className="text-sm">Total Hashrate: <span className="font-bold">{formatHashrate(miner.stats?.totalHashrate || 0)}</span></span></div>
                                <div className="flex items-center space-x-2"><ClockIcon className="w-5 h-5 text-gray-400"/><span className="text-sm">Uptime: <span className="font-bold">{dayjs.duration(miner.stats?.uptime || 0, 'seconds').humanize()}</span></span></div>
                                <div className="flex items-center space-x-2"><span className="font-bold text-green-500">A:</span><span className="text-sm">{miner.stats?.acceptedShares || 0}</span> <span className="font-bold text-red-500">R:</span><span className="text-sm">{miner.stats?.rejectedShares || 0}</span></div>
                                <div className="flex items-center space-x-2"><CpuChipIcon className="w-5 h-5 text-gray-400"/><span className="text-sm">Power: <span className="font-bold">{miner.stats?.totalPower || 0} W</span></span></div>
                            </div>
                            <div className="space-y-1">
                                {miner.stats?.devices.map(dev => <DeviceStat key={dev.id} device={dev} />)}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default MultiMinerEmulator;