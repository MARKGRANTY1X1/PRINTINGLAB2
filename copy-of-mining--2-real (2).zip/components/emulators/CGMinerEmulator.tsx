
import React, { useState, useEffect, useCallback, useRef } from 'react';
import * as backendAPI from '../../services/electronAPI';
import { EmulatorLog } from '../../types';
import TerminalOutput from './TerminalOutput';
import dayjs from 'dayjs';

const CGMinerEmulator: React.FC = () => {
    const [isRunning, setIsRunning] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [logs, setLogs] = useState<EmulatorLog[]>([]);
    const [input, setInput] = useState('');

    const addLog = useCallback((type: EmulatorLog['type'], content: string) => {
        setLogs(prev => [...prev, { timestamp: dayjs().format('HH:mm:ss'), type, content }]);
    }, []);

    const processUpdate = useCallback((data: any) => {
        addLog(data.type, data.content);
    }, [addLog]);

    useEffect(() => {
        const removeListener = backendAPI.onEmulatorUpdate('cgminer', processUpdate);
        return () => removeListener();
    }, [processUpdate]);

    const handleStart = async () => {
        setIsLoading(true);
        setLogs([]);
        const success = await backendAPI.startEmulator('cgminer');
        if (success) {
            setIsRunning(true);
        } else {
            addLog('ERROR', 'Failed to start CGMiner emulator.');
        }
        setIsLoading(false);
    };

    const handleStop = async () => {
        setIsLoading(true);
        await backendAPI.stopEmulator('cgminer');
        setIsRunning(false);
        setIsLoading(false);
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            const command = input.toLowerCase().trim();
            if (command === 'q') {
                handleStop();
            } else if (['s', 'd'].includes(command)) {
                backendAPI.sendEmulatorCommand('cgminer', command);
            } else {
                 addLog('INFO', `Unknown command: ${input}`);
            }
            setInput('');
        }
    };

    return (
        <div className="bg-light-card dark:bg-dark-card p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">CGMiner Emulator</h2>
                <button
                    onClick={isRunning ? handleStop : handleStart}
                    disabled={isLoading}
                    className={`px-4 py-2 font-bold rounded-md transition-colors w-32 ${
                        isRunning 
                        ? 'bg-red-600 hover:bg-red-700 text-white' 
                        : 'bg-primary hover:bg-primary-focus text-primary-content'
                    } disabled:bg-gray-500`}
                >
                    {isLoading ? '...' : isRunning ? 'Stop' : 'Start'}
                </button>
            </div>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
                A simulation of the classic CGMiner text-based interface. Type commands below.
            </p>
            <TerminalOutput logs={logs} variant="cgminer" />
            <div className="mt-2 flex items-center bg-gray-900 p-2 rounded-b-md">
                <span className="text-green-400 font-mono text-sm mr-2">{'>'}</span>
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyPress}
                    placeholder={isRunning ? "Commands: (S)ettings, (D)evices, (Q)uit" : "Start emulator to enter commands"}
                    disabled={!isRunning}
                    className="flex-1 bg-transparent text-gray-300 focus:outline-none font-mono text-sm"
                />
            </div>
        </div>
    );
};

export default CGMinerEmulator;
