
import { PayoutCoin, MinerPath, Wallet, OverclockProfile, EmulatorConfig } from '../types';

/**
 * NOTE: This file is the bridge between the React UI (Renderer Process) and the
 * main desktop application backend (Main Process in Electron).
 *
 * It assumes a preload script has securely exposed functions onto the `window` object
 * under the `window.electronAPI` namespace. These functions use IPC (Inter-Process Communication)
 * to trigger actions (like starting a miner) in the main process, which has access to
 * Node.js APIs like `child_process` and `fs`.
 */

declare global {
  interface Window {
    electronAPI: {
      // FIX: Added missing type definitions for update manager functions.
      checkForUpdate: () => void;
      onUpdateDownloaded: (callback: () => void) => void;
      restartApp: () => Promise<void>;
      startMiner: (path: string, args: string) => Promise<boolean>;
      stopMiner: () => Promise<boolean>;
      onMinerOutput: (callback: (data: string) => void) => void;
      offMinerOutput: () => void;
      onMinerExit: (callback: (code: number) => void) => void;
      offMinerExit: () => void;
      selectMinerPath: () => Promise<string | null>;
      scanForMiners: () => Promise<MinerPath[]>;
      selectDirectory: () => Promise<string | null>;
      scanDirectoryForMiners: (path: string) => Promise<MinerPath[]>;
      createWallet: () => Promise<Wallet>;
      calculateFee: (coin: PayoutCoin, amount: number) => Promise<number>;
      executeSend: (coin: PayoutCoin, address: string, amount: number) => Promise<string>;
      getExplorerLink: (coin: PayoutCoin, txHash: string) => Promise<string>;
      applyOverclock: (profile: OverclockProfile) => Promise<boolean>;
      resetOverclock: () => Promise<boolean>;
      
      // Emulator Control
      startEmulator: (type: 'cgminer' | 'gminer') => Promise<boolean>;
      stopEmulator: (type: 'cgminer' | 'gminer') => Promise<boolean>;
      sendEmulatorCommand: (type: 'cgminer' | 'gminer', command: string) => void;
      onEmulatorUpdate: (type: 'cgminer' | 'gminer', callback: (data: any) => void) => void;
      offEmulatorUpdate: (type: 'cgminer' | 'gminer') => void;
    };
  }
}

/**
 * Checks if the app is running in the Electron environment.
 * @returns {boolean} True if the Electron API is available, false otherwise.
 */
export const isElectron = (): boolean => {
    return window.electronAPI !== undefined;
}


// --- Update Management ---
export const checkForUpdate = (): void => {
    if (isElectron()) {
        window.electronAPI.checkForUpdate();
    }
};


// --- Wallet Management ---
export const createWallet = (): Promise<Wallet> => {
    if (!isElectron()) {
        console.warn("[API Bridge] Mocking wallet creation for web preview.");
        return Promise.resolve({
            mnemonic: 'spirit solar stone jewel hero viable sweet amazing purpose success balance rescue',
            address: `mockwallet${Date.now()}`
        });
    }
    return window.electronAPI.createWallet();
};

export const calculateFee = (coin: PayoutCoin, amount: number): Promise<number> => {
    if (!isElectron()) return Promise.resolve(0.0005); // Return a placeholder for UI
    return window.electronAPI.calculateFee(coin, amount);
};

export const executeSend = (coin: PayoutCoin, address: string, amount: number): Promise<string> => {
    if (!isElectron()) {
        console.warn(`[API Bridge] Mocking send transaction for web preview: ${amount} ${coin.ticker} to ${address}`);
        // Simulate network delay for realism in UI
        return new Promise(resolve => setTimeout(() => resolve(`mock_tx_${Date.now()}`), 1500));
    }
    return window.electronAPI.executeSend(coin, address, amount);
};

export const getExplorerLink = (coin: PayoutCoin, txHash: string): Promise<string> => {
    if (!isElectron()) return Promise.resolve(`https://some-explorer.com/${coin.ticker}/tx/${txHash}`);
    return window.electronAPI.getExplorerLink(coin, txHash);
};


// --- Miner Process Management ---

export const selectMinerPath = async (): Promise<string | null> => {
  if (!isElectron()) {
    alert("This feature is only available in the desktop app.");
    return null;
  }
  return window.electronAPI.selectMinerPath();
};

export const scanForMiners = async (): Promise<MinerPath[]> => {
    if (!isElectron()) {
        console.warn("Scanning is disabled in web preview.");
        return [];
    }
    return window.electronAPI.scanForMiners();
};

export const selectDirectory = async (): Promise<string | null> => {
    if (!isElectron()) {
        alert("This feature is only available in the desktop app.");
        return null;
    }
    return window.electronAPI.selectDirectory();
}

export const scanDirectoryForMiners = async (path: string): Promise<MinerPath[]> => {
    if (!isElectron()) {
        console.warn("Scanning a specific directory is disabled in web preview.");
        return [];
    }
    return window.electronAPI.scanDirectoryForMiners(path);
}


export const startMinerProcess = async (minerPath: string, args: string): Promise<boolean> => {
  if (!isElectron()) {
    console.error("Cannot start miner in a web browser environment.");
    return false;
  }
  console.log(`[API Bridge] Requesting to start miner: ${minerPath} with args: ${args}`);
  return window.electronAPI.startMiner(minerPath, args);
};

export const stopMinerProcess = async (): Promise<boolean> => {
  if (!isElectron()) return false;
  console.log('[API Bridge] Requesting to stop miner.');
  return window.electronAPI.stopMiner();
};

export const onMinerOutput = (callback: (data: string) => void): (() => void) => {
  if (isElectron()) {
    window.electronAPI.onMinerOutput(callback);
    // Return the unsubscribe function
    return () => window.electronAPI.offMinerOutput();
  }
  // Return a no-op unsubscribe function for web environment
  return () => {};
};

export const onMinerExit = (callback: (code: number) => void): (() => void) => {
    if (isElectron()) {
        window.electronAPI.onMinerExit(callback);
        return () => window.electronAPI.offMinerExit();
    }
    return () => {};
}

// --- Overclocking ---
export const applyOverclock = async (profile: OverclockProfile): Promise<boolean> => {
    if (!isElectron()) {
        console.warn("[API Bridge] Mocking overclock apply for web preview:", profile);
        return Promise.resolve(true);
    }
    return window.electronAPI.applyOverclock(profile);
}

export const resetOverclock = async (): Promise<boolean> => {
    if (!isElectron()) {
        console.warn("[API Bridge] Mocking overclock reset for web preview.");
        return Promise.resolve(true);
    }
    return window.electronAPI.resetOverclock();
}

// --- Emulator APIs ---
export const startEmulator = (type: 'cgminer' | 'gminer') => {
    if (isElectron()) return window.electronAPI.startEmulator(type);
    return Promise.resolve(false);
}

export const stopEmulator = (type: 'cgminer' | 'gminer') => {
    if (isElectron()) return window.electronAPI.stopEmulator(type);
    return Promise.resolve(false);
}

export const sendEmulatorCommand = (type: 'cgminer' | 'gminer', command: string) => {
    if (isElectron()) window.electronAPI.sendEmulatorCommand(type, command);
}

export const onEmulatorUpdate = (type: 'cgminer' | 'gminer', callback: (data: any) => void) => {
    if (isElectron()) {
        window.electronAPI.onEmulatorUpdate(type, callback);
        return () => window.electronAPI.offEmulatorUpdate(type);
    }
    return () => {};
}