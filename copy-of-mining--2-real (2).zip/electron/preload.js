
// electron/preload.js
const { contextBridge, ipcRenderer } = require('electron');

// Securely expose a controlled API to the renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  // --- Update API ---
  checkForUpdate: () => ipcRenderer.send('check-for-update'),
  onUpdateDownloaded: (callback) => ipcRenderer.on('update-downloaded', (_event, value) => callback(value)),
  restartApp: () => ipcRenderer.invoke('restart-app'),

  // Miner Process Management
  startMiner: (path, args) => ipcRenderer.invoke('start-miner', path, args),
  stopMiner: () => ipcRenderer.invoke('stop-miner'),
  
  onMinerOutput: (callback) => {
    ipcRenderer.on('miner-output', (_event, value) => callback(value));
  },
  offMinerOutput: () => {
    ipcRenderer.removeAllListeners('miner-output');
  },
  onMinerExit: (callback) => {
    ipcRenderer.on('miner-exit', (_event, value) => callback(value));
  },
  offMinerExit: () => {
    ipcRenderer.removeAllListeners('miner-exit');
  },
  
  // File System Interaction
  selectMinerPath: () => ipcRenderer.invoke('select-miner-path'),
  scanForMiners: () => ipcRenderer.invoke('scan-for-miners'),
  selectDirectory: () => ipcRenderer.invoke('select-directory'),
  scanDirectoryForMiners: (path) => ipcRenderer.invoke('scan-directory-for-miners', path),

  // Wallet Functions
  createWallet: () => ipcRenderer.invoke('create-wallet'),
  calculateFee: (coin, amount) => ipcRenderer.invoke('calculate-fee', coin, amount),
  executeSend: (coin, address, amount) => ipcRenderer.invoke('execute-send', coin, address, amount),
  getExplorerLink: (coin, txHash) => ipcRenderer.invoke('get-explorer-link', coin, txHash),
  
  // Overclocking
  applyOverclock: (profile) => ipcRenderer.invoke('apply-overclock', profile),
  resetOverclock: () => ipcRenderer.invoke('reset-overclock'),
  
  // Emulator Control
  startEmulator: (type) => ipcRenderer.invoke('start-emulator', type),
  stopEmulator: (type) => ipcRenderer.invoke('stop-emulator', type),
  sendEmulatorCommand: (type, command) => ipcRenderer.send('emulator-command', type, command),
  onEmulatorUpdate: (type, callback) => ipcRenderer.on(`${type}-update`, (_event, data) => callback(data)),
  offEmulatorUpdate: (type) => ipcRenderer.removeAllListeners(`${type}-update`),
});
