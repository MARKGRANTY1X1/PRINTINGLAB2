
// electron/main.js
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs/promises');
const os = require('os');
const crypto = require('crypto');

// --- New Imports for Backend Server & Updater ---
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const cors = require('cors');
const { autoUpdater } = require('electron-updater');

// --- New Imports for Emulators ---
const { MINERS_CONFIG } = require('./emulators/miners_config.js');
const MiningEmulatorEngine = require('./emulators/MiningEmulatorEngine.js');

let mainWindow;
let minerProcess = null;

// --- Auto Updater Logic ---
autoUpdater.autoDownload = true;
autoUpdater.on('update-available', () => {
  console.log('Update available, starting download.');
  if (mainWindow) {
    mainWindow.webContents.send('update-message', 'Update available, downloading...');
  }
});
autoUpdater.on('update-downloaded', () => {
  console.log('Update downloaded.');
   if (mainWindow) {
    mainWindow.webContents.send('update-downloaded');
  }
});
autoUpdater.on('error', (err) => {
  console.error('Error in auto-updater.', err);
  if (mainWindow) {
    mainWindow.webContents.send('update-message', `Update error: ${err.message}`);
  }
});

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 940,
    minHeight: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#1f2937',
  });

  mainWindow.loadFile(path.join(__dirname, '../index.html'));

  mainWindow.once('ready-to-show', () => {
    // Check for updates on startup
    autoUpdater.checkForUpdatesAndNotify();
  });
}

// --- Backend Server Setup (Express + WebSockets) ---
const backendApp = express();
const server = http.createServer(backendApp);
const wss = new WebSocketServer({ server });

// Serves the 'dist' folder where electron-builder puts update files.
const updateDistPath = path.join(__dirname, '..', 'dist');
backendApp.use('/updates', express.static(updateDistPath));


wss.on('connection', ws => {
  console.log('Client connected to WebSocket');
  ws.on('close', () => console.log('Client disconnected'));
});

function broadcastUpdate() {
  console.log('Broadcasting update notification to all clients.');
  wss.clients.forEach(client => {
    if (client.readyState === require('ws').OPEN) {
      client.send(JSON.stringify({ type: 'update-available' }));
    }
  });
  autoUpdater.checkForUpdates();
}

backendApp.use(cors());
backendApp.use(express.json());

// Admin endpoint to trigger an update
backendApp.post('/api/admin/trigger-update', (req, res) => {
  console.log('Update trigger received. Broadcasting to clients.');
  broadcastUpdate();
  res.status(200).json({ message: 'Update check triggered successfully for all clients.' });
});

// --- BFGMiner Emulator API ---
const bfgminerInstances = new Map();

backendApp.post('/api/bfgminer/create', (req, res) => {
    const id = `bfg-instance-${crypto.randomBytes(4).toString('hex')}`;
    const config = MINERS_CONFIG.bfgminer;
    const engine = new MiningEmulatorEngine(config, id);
    engine.start();

    bfgminerInstances.set(id, engine);
    console.log(`[BFGMiner API] Created instance: ${id}`);
    res.status(201).json({ id, status: 'running' });
});

backendApp.get('/api/bfgminer/status/:id', (req, res) => {
    const { id } = req.params;
    const engine = bfgminerInstances.get(id);
    if (engine) {
        res.status(200).json({ id, status: 'running', stats: engine.getStats() });
    } else {
        res.status(404).json({ error: 'Miner instance not found' });
    }
});

backendApp.post('/api/bfgminer/stop/:id', (req, res) => {
    const { id } = req.params;
    const engine = bfgminerInstances.get(id);
    if (engine) {
        engine.stop();
        bfgminerInstances.delete(id);
        console.log(`[BFGMiner API] Stopped instance: ${id}`);
        res.status(200).json({ id, status: 'stopped' });
    } else {
        res.status(404).json({ error: 'Miner instance not found' });
    }
});

backendApp.get('/api/bfgminer/list', (req, res) => {
    const instances = Array.from(bfgminerInstances.keys()).map(id => ({
        id,
        status: 'running',
        stats: bfgminerInstances.get(id).getStats(),
    }));
    res.status(200).json(instances);
});


const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});


app.whenReady().then(() => {
  createWindow();
  setInterval(() => {
    autoUpdater.checkForUpdates();
  }, 3600 * 1000);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// --- IPC Handlers for Backend Logic ---

ipcMain.on('check-for-update', () => {
  console.log('Renderer requested an update check.');
  autoUpdater.checkForUpdates();
});

ipcMain.handle('restart-app', () => {
  console.log('Restarting app to install update.');
  autoUpdater.quitAndInstall();
});


// Miner Control
ipcMain.handle('start-miner', (event, minerPath, command) => {
  if (minerProcess) {
    console.warn('Attempted to start miner, but one is already running.');
    return false;
  }
  
  console.log(`Starting miner: ${minerPath} with command: ${command}`);

  try {
    const args = command.split(' ');
    minerProcess = spawn(minerPath, args, { shell: true, detached: false });

    minerProcess.stdout.on('data', (data) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('miner-output', data.toString());
      }
    });
    minerProcess.stderr.on('data', (data) => {
       if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('miner-output', data.toString());
      }
    });

    minerProcess.on('close', (code) => {
      console.log(`Miner process exited with code ${code}`);
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('miner-exit', code);
      }
      minerProcess = null;
    });

    minerProcess.on('error', (err) => {
        console.error('Failed to start miner process:', err);
        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('miner-output', `[ERROR] Failed to start miner: ${err.message}`);
        }
        minerProcess = null;
    });
    
    return true; // Success
  } catch (error) {
    console.error("Fatal error spawning miner process:", error);
     if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('miner-output', `[ERROR] Could not launch miner: ${error.message}`);
    }
    return false; // Failure
  }
});

ipcMain.handle('stop-miner', () => {
  if (minerProcess) {
    console.log('Stopping miner process...');
    const killed = minerProcess.kill();
    if (killed) {
        console.log('Miner process terminated successfully.');
    } else {
        console.error('Failed to terminate miner process.');
    }
    minerProcess = null;
    return true;
  }
  return false;
});

// File System Interaction
ipcMain.handle('select-miner-path', async () => {
    const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Miner Executable',
        properties: ['openFile'],
        filters: [
            { name: 'Executables', extensions: ['exe'] },
            { name: 'All Files', extensions: ['*'] }
        ]
    });
    if (canceled || filePaths.length === 0) {
        return null;
    }
    return filePaths[0];
});

ipcMain.handle('select-directory', async () => {
    const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Folder to Scan for Miners',
        properties: ['openDirectory']
    });
    if (canceled || filePaths.length === 0) {
        return null;
    }
    return filePaths[0];
});


const MINER_FILENAMES = ['t-rex.exe', 'xmrig.exe', 'teamredminer.exe', 'lolminer.exe'];

const scanDirectory = async (directoryPath) => {
    const foundMiners = [];
    try {
        const files = await fs.readdir(directoryPath, { recursive: true, withFileTypes: true });
        for (const file of files) {
            if (file.isFile() && MINER_FILENAMES.includes(file.name.toLowerCase())) {
                const fullPath = path.join(file.path, file.name);
                foundMiners.push({
                    id: `found-${Date.now()}-${Math.random()}`,
                    name: file.name.split('.')[0],
                    path: fullPath,
                });
            }
        }
    } catch (error) {
        console.warn(`Could not scan directory ${directoryPath}:`, error.message);
    }
    return foundMiners;
}

ipcMain.handle('scan-directory-for-miners', async (event, directoryPath) => {
    if (!directoryPath) return [];
    return scanDirectory(directoryPath);
});

ipcMain.handle('scan-for-miners', async () => {
    const homeDir = os.homedir();
    const searchPaths = [
        path.join(homeDir, 'Downloads'),
        path.join(homeDir, 'Desktop'),
        'C:\\Miners',
    ];
    
    let allFoundMiners = [];

    for (const searchPath of searchPaths) {
        const minersInPath = await scanDirectory(searchPath);
        allFoundMiners = [...allFoundMiners, ...minersInPath];
    }
    
    // Remove duplicates based on path
    const uniqueMiners = allFoundMiners.filter((miner, index, self) =>
      index === self.findIndex((t) => t.path === miner.path)
    );
    
    return uniqueMiners;
});


// --- Emulator IPC Handlers ---
let emulators = {
  cgminer: null,
  gminer: null,
};

function startEmulator(type) {
  if (emulators[type]) {
    console.log(`Emulator ${type} is already running.`);
    return false;
  }
  
  const config = MINERS_CONFIG[type];
  if (!config) {
    console.error(`No config found for emulator type: ${type}`);
    return false;
  }

  const engine = new MiningEmulatorEngine(config, type);
  
  engine.on('update', (data) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send(`${type}-update`, data);
    }
  });

  engine.start();
  emulators[type] = engine;
  console.log(`Started ${type} emulator.`);
  return true;
}

function stopEmulator(type) {
    if (emulators[type]) {
        emulators[type].stop();
        emulators[type] = null;
        console.log(`Stopped ${type} emulator.`);
        return true;
    }
    return false;
}

ipcMain.handle('start-emulator', (event, type) => startEmulator(type));
ipcMain.handle('stop-emulator', (event, type) => stopEmulator(type));
ipcMain.on('emulator-command', (event, type, command) => {
    if (emulators[type]) {
        emulators[type].handleCommand(command);
    }
});


// Wallet Functions (Mocked - requires real crypto libraries)
ipcMain.handle('create-wallet', async () => {
    const words = ['spirit', 'solar', 'stone', 'jewel', 'hero', 'viable', 'sweet', 'amazing', 'purpose', 'success', 'balance', 'rescue'];
    const mnemonic = words.sort(() => 0.5 - Math.random()).join(' ');
    const address = '0x' + crypto.randomBytes(20).toString('hex');
    return { mnemonic, address };
});

ipcMain.handle('calculate-fee', async (event, coin, amount) => {
    return 0.0005; // Mock fee
});

ipcMain.handle('execute-send', async (event, coin, address, amount) => {
    console.log(`[BACKEND MOCK] Executing send: ${amount} ${coin.ticker} to ${address}`);
    return `mock_tx_${crypto.randomBytes(16).toString('hex')}`;
});

ipcMain.handle('get-explorer-link', async (event, coin, txHash) => {
    const explorers = {
        'BTC': 'https://www.blockchain.com/btc/tx/',
        'ETC': 'https://etc.2miners.com/tx/',
        'XMR': 'https://www.exploremonero.com/transaction/',
        'RVN': 'https://ravencoin.network/tx/',
        'default': 'https://some-explorer.com/tx/'
    };
    const baseUrl = explorers[coin.ticker] || explorers.default;
    return `${baseUrl}${txHash}`;
});

// Overclocking (Mocked)
ipcMain.handle('apply-overclock', async (event, profile) => {
    console.log(`[BACKEND MOCK] Applying overclock profile "${profile.name}":`, profile);
    return true; // Assume success for mock
});

ipcMain.handle('reset-overclock', async () => {
    console.log('[BACKEND MOCK] Resetting overclock settings to default.');
    return true; // Assume success for mock
});
