
const MINERS_CONFIG = {
  cgminer: {
    devices: [
      { id: 'ASIC-1', type: 'ASIC', name: 'Antminer S19', baseHashrate: 110000000, powerDraw: 3250, algorithm: 'SHA-256' },
      { id: 'ASIC-2', type: 'ASIC', name: 'Antminer L7', baseHashrate: 9500, powerDraw: 3425, algorithm: 'Scrypt' },
    ],
    difficulty: 1000000000,
  },
  gminer: {
    devices: [
      { id: 'GPU-0', type: 'GPU', name: 'NVIDIA RTX 4090', baseHashrate: 125, powerDraw: 350, algorithm: 'Etchash' },
      { id: 'GPU-1', type: 'GPU', name: 'NVIDIA RTX 3080', baseHashrate: 98, powerDraw: 240, algorithm: 'Etchash' },
    ],
    difficulty: 8720000,
    devFee: 1.0, // 1%
  },
  bfgminer: {
    // This is a template for creating new instances via the API
    devices: [
       { id: 'FPGA-1', type: 'FPGA', name: 'Xilinx VU9P', baseHashrate: 35000, powerDraw: 200, algorithm: 'Keccak' },
    ],
    difficulty: 50000000,
  }
};

module.exports = { MINERS_CONFIG };
