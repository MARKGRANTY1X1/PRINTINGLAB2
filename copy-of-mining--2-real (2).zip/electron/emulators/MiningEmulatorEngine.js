
const { EventEmitter } = require('events');

class MiningEmulatorEngine extends EventEmitter {
  constructor(config, type) {
    super();
    this.config = config;
    this.type = type;
    this.devices = config.devices;
    this.difficulty = config.difficulty;
    this.devFee = config.devFee || 0;

    this.interval = null;
    this.startTime = null;
    this.stats = {};
    
    this.devFeeCounter = 0;
    this.devFeeInterval = 60; // every 60 ticks (5 mins)
  }

  start() {
    this.startTime = Date.now();
    this._initializeStats();
    this.interval = setInterval(() => this._tick(), 5000); // Update every 5 seconds
    this.emit('update', { type: 'INFO', content: `Emulator started for ${this.type}.` });
  }

  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
      this.emit('update', { type: 'INFO', content: `Emulator stopped for ${this.type}.` });
    }
  }

  getStats() {
    return this.stats;
  }

  handleCommand(command) {
    // For CGMiner style commands
    if (command === 'd') { // devices
        const deviceLines = this.stats.devices.map((dev, i) => `[Device ${i}] ${dev.name} | Temp: ${dev.temperature.toFixed(1)}C | Fan: ${dev.fanSpeed}% | Power: ${dev.power}W`);
        this.emit('update', {type: 'INFO', content: ['Device Details:', ...deviceLines].join('\n')});
    }
    if (command === 's') { // settings
        const settingsLines = [
            'Emulator Settings:',
            `  - Type: ${this.type}`,
            `  - Devices: ${this.devices.length}`,
            `  - Difficulty: ${this.difficulty.toExponential(2)}`
        ];
        this.emit('update', {type: 'INFO', content: settingsLines.join('\n')});
    }
  }

  _initializeStats() {
    this.stats = {
      totalHashrate: 0,
      totalPower: 0,
      uptime: 0,
      acceptedShares: 0,
      rejectedShares: 0,
      lastShareTime: null,
      devices: this.devices.map(device => ({
        id: device.id,
        name: device.name,
        type: device.type,
        hashrate: 0,
        temperature: 60 + Math.random() * 5,
        fanSpeed: 50 + Math.random() * 10,
        power: device.powerDraw * 0.9,
        acceptedShares: 0,
        rejectedShares: 0,
      }))
    };
  }

  _tick() {
    const now = Date.now();
    this.stats.uptime = Math.floor((now - this.startTime) / 1000);

    let totalHashrate = 0;
    let totalPower = 0;

    this.stats.devices.forEach((device, index) => {
      const baseDevice = this.devices[index];
      
      // Fluctuate hashrate around base +/- 5%
      const hashrateFluctuation = (Math.random() - 0.5) * 0.1 * baseDevice.baseHashrate;
      device.hashrate = baseDevice.baseHashrate + hashrateFluctuation;
      
      // Simulate temperature based on hashrate
      const tempFluctuation = (device.hashrate / baseDevice.baseHashrate - 1) * 20;
      device.temperature = 65 + tempFluctuation + (Math.random() - 0.5) * 2;
      device.temperature = Math.max(50, Math.min(95, device.temperature));

      // Simulate fan speed based on temp
      device.fanSpeed = 30 + (device.temperature - 50) * 1.5 + (Math.random() - 0.5) * 5;
      device.fanSpeed = Math.max(0, Math.min(100, Math.round(device.fanSpeed)));
      
      // Simulate power draw
      device.power = baseDevice.powerDraw * (0.9 + (device.hashrate / baseDevice.baseHashrate - 1) * 0.2 + (Math.random() - 0.5) * 0.05);
      device.power = Math.round(device.power);

      totalHashrate += device.hashrate;
      totalPower += device.power;

      // Simulate finding shares
      // Probability of finding a share in this tick (5s)
      const shareProbability = (device.hashrate * 1e6 * 5) / this.difficulty;
      if (Math.random() < shareProbability) {
        if (Math.random() > 0.02) { // 2% chance of rejected share
          device.acceptedShares++;
          this.stats.acceptedShares++;
          this.stats.lastShareTime = now;
          this.emit('update', { type: 'SHARE_FOUND', content: `Share accepted from ${device.name}!` });
        } else {
          device.rejectedShares++;
          this.stats.rejectedShares++;
          this.emit('update', { type: 'ERROR', content: `Share rejected from ${device.name}.` });
        }
      }
    });

    this.stats.totalHashrate = totalHashrate;
    this.stats.totalPower = totalPower;

    // Emit dev fee message for GMiner
    if (this.type === 'gminer') {
        this.devFeeCounter++;
        if (this.devFeeCounter >= this.devFeeInterval) {
            this.devFeeCounter = 0;
            this.emit('update', { type: 'DEV_FEE', content: `Starting dev fee mining (${this.devFee}%)` });
            setTimeout(() => {
                 this.emit('update', { type: 'DEV_FEE', content: 'Finished dev fee mining' });
            }, 3000);
        }
    }
    
    this.emit('update', { type: 'STATUS', content: this.stats });
  }
}

module.exports = MiningEmulatorEngine;
