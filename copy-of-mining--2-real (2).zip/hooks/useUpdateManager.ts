import { useState, useEffect } from 'react';
import { useToast } from '../contexts/ToastContext';
import { isElectron, checkForUpdate } from '../services/electronAPI';

const API_BASE_URL = 'http://localhost:3001';
const WS_URL = 'ws://localhost:3001';

export const useUpdateManager = () => {
  const { addToast } = useToast();
  const [isUpdateDownloaded, setIsUpdateDownloaded] = useState(false);

  useEffect(() => {
    // The entire update mechanism relies on the local Electron backend server.
    // If we're not in Electron (e.g., in a web preview), we should not attempt to connect.
    if (!isElectron()) {
      console.log("Update manager is disabled in web preview mode as it cannot connect to the local backend server.");
      return; // Do nothing.
    }

    // --- WebSocket Logic ---
    const ws = new WebSocket(WS_URL);

    ws.onopen = () => console.log('Update manager connected to WebSocket.');
    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.type === 'update-available') {
        console.log('Update notification received via WebSocket. Triggering check.');
        addToast('New update available! Checking for updates now...', 'info');
        checkForUpdate();
      }
    };
    ws.onerror = (_event) => {
        // This will now only be logged if something is wrong with the backend server in Electron.
        console.error(`Update Manager: WebSocket connection to ${WS_URL} failed. Please ensure the local backend server is running correctly.`);
    };

    // --- Electron-Specific Listeners ---
    // This is the correct way for the renderer to know an update is ready.
    window.electronAPI.onUpdateDownloaded(() => {
      console.log('Renderer process notified that update is downloaded.');
      setIsUpdateDownloaded(true);
    });

    // --- Cleanup ---
    return () => {
      ws.close();
      // Clean up Electron listener if needed (though preload does this implicitly on context loss)
    };
  }, [addToast]);
  
  const restartApp = () => {
    if (isElectron()) {
      window.electronAPI.restartApp();
    }
  };

  return { isUpdateDownloaded, restartApp };
};
