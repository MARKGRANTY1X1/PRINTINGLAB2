
import { useState, useCallback } from 'react';
import { ChartDataPoint, LogEntry, LogLevel } from '../types';
import dayjs from 'dayjs';

// This simulator is intentionally disabled to ensure the app only runs in real desktop mode.
export const useMiningSimulator = () => {
    const [logs, setLogs] = useState<LogEntry[]>([]);

    const addLog = useCallback((message: string, level: LogLevel) => {
        const newLog: LogEntry = {
            timestamp: dayjs().format('HH:mm:ss'),
            message,
            level,
        };
        setLogs(prev => [newLog, ...prev]);
    }, []);

    const startMining = useCallback(async (): Promise<boolean> => {
        addLog('ERROR: Mining simulator was called. This should not happen in the desktop application. Please check your configuration and restart the app.', LogLevel.ERROR);
        return false;
    }, [addLog]);

    const stopMining = useCallback(() => {
        // This is a non-functional stub.
    }, []);

    return {
        isStarting: false,
        isMining: false,
        miningLogs: logs,
        startMining,
        stopMining,
        hashrate: 0,
        acceptedShares: 0,
        rejectedShares: 0,
        miningChartData: [] as ChartDataPoint[],
    };
};