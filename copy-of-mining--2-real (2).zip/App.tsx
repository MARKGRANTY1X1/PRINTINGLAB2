
import React, { createContext, useState, useEffect, useMemo, useCallback } from 'react';
import useLocalStorage from './hooks/useLocalStorage';
import { useWalletManager } from './hooks/useWalletManager';
import { useMinerManager } from './hooks/useMinerManager';
import { useStakingEngine } from './hooks/useStakingEngine';
import { useToast, ToastProvider } from './contexts/ToastContext';
import {
  User, AppSettings, Coin, PayoutCoin, ChartDataPoint, LogEntry,
  MiningDevice, MiningIntensity, Validator, PoolStats, StakedPosition, Wallet, Transaction,
  ViewType
} from './types';
import { DEFAULT_COINS, PAYOUT_COINS, DEFAULT_USER, DEFAULT_SETTINGS, VALIDATORS, DEFAULT_PAYOUT_COIN_ID, DEFAULT_COIN_ID } from './constants';
import { fetchCoinMarketData, fetchPoolStats } from './services/cryptoDataAPI';
import * as backendAPI from './services/electronAPI';
import { useUpdateManager } from './hooks/useUpdateManager'; // Import the new hook

import { Sidebar } from './components/Sidebar';
import Dashboard from './components/Dashboard';
import SettingsPage from './components/SettingsPage';
// FIX: Changed import to a named import as WalletPage does not have a default export.
import { WalletPage } from './components/WalletPage';
import StakingPage from './components/StakingPage';
import ReferralPage from './components/ReferralPage';
import SetupGuidePage from './components/SetupGuidePage';
import RoadmapPage from './components/RoadmapPage';
// FIX: Added import for UsersPage to be used in the router.
import UsersPage from './components/UsersPage';
import LoginPage from './components/LoginPage';
import WalletSetupPage from './components/WalletSetupPage';
import ActionConfirmationModal from './components/ActionConfirmationModal';
import { AppContext } from './contexts/AppContext';
import EmulatorsPage from './components/EmulatorsPage';

const UpdateNotification: React.FC<{ onRestart: () => void }> = ({ onRestart }) => (
  <div className="fixed bottom-5 left-1/2 -translate-x-1/2 bg-blue-600 text-white py-3 px-6 rounded-lg shadow-2xl flex items-center gap-4 z-50">
    <p className="font-semibold">A new version is ready!</p>
    <button
      onClick={onRestart}
      className="bg-white text-blue-600 font-bold py-1.5 px-4 rounded-md hover:bg-blue-100 transition-colors"
    >
      Restart to Update
    </button>
  </div>
);


const AppContent: React.FC = () => {
  const [currentUser, setCurrentUser] = useLocalStorage<User | null>('minehub-user', null);
  // FIX: Added state for managing all users.
  const [users, setUsers] = useLocalStorage<User[]>('minehub-users', [DEFAULT_USER]);
  const [activeView, setActiveView] = useState<ViewType>('dashboard');

  const [allCoins, setAllCoins] = useState<Coin[]>([]);
  const [allPayoutCoins, setAllPayoutCoins] = useState<PayoutCoin[]>([]);

  const [selectedValidatorId, setSelectedValidatorId] = useLocalStorage<string | null>('selected-validator', null);

  const { addToast } = useToast();
  const { isUpdateDownloaded, restartApp } = useUpdateManager(); // Use the update manager
  
  const handleLogin = (email: string, password: string): { status: 'success' | 'failure' | 'conflict'; user?: User } => {
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (user) {
        if(user.status !== 'offline') {
            return { status: 'conflict', user };
        }
        // FIX: Used 'as const' to prevent TypeScript from widening the 'status' property to a generic 'string' type,
        // ensuring it matches the specific 'online' | 'offline' | 'mining' union type required by the User interface.
        const loggedInUser = { ...user, status: 'online' as const, lastSeen: new Date().toISOString() };
        setCurrentUser(loggedInUser);
        setUsers(prev => prev.map(u => u.id === user.id ? loggedInUser : u));
        return { status: 'success', user: loggedInUser };
    }
    return { status: 'failure' };
  };
  
  const handleForceLogin = (userToLogin: User) => {
    // Log out the "other" session by setting its status to offline if it's not already.
    const updatedUsers = users.map(u => {
        if (u.id === userToLogin.id) {
             // FIX: Used 'as const' to prevent TypeScript from widening the 'status' property to a generic 'string' type.
             return { ...userToLogin, status: 'online' as const, lastSeen: new Date().toISOString() };
        }
        return u;
    });
    setUsers(updatedUsers);
    // FIX: Used 'as const' to prevent TypeScript from widening the 'status' property to a generic 'string' type.
    setCurrentUser({ ...userToLogin, status: 'online' as const, lastSeen: new Date().toISOString() });
    addToast(`Successfully logged in as ${userToLogin.username}.`, 'success');
  };


  useEffect(() => {
    const fetchData = async () => {
      try {
        const marketData = await fetchCoinMarketData();
        const coinsWithData = DEFAULT_COINS.map(c => ({
          ...c,
          ...marketData[c.id],
        }));
        setAllCoins(coinsWithData as Coin[]);

        const payoutCoinsWithData = PAYOUT_COINS.map(c => ({
          ...c,
          ...marketData[c.id],
        }));
        setAllPayoutCoins(payoutCoinsWithData as PayoutCoin[]);

      } catch (error) {
        console.error("Failed to fetch initial coin data:", error);
        addToast("Could not fetch live market data.", 'error');
        setAllCoins(DEFAULT_COINS as Coin[]);
        setAllPayoutCoins(PAYOUT_COINS as PayoutCoin[]);
      }
    };
    fetchData();
    const interval = setInterval(fetchData, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, [addToast]);

  const setSettings = (newSettings: Partial<AppSettings> | ((prev: AppSettings) => AppSettings)) => {
    if (!currentUser) return;
    const updatedSettings = typeof newSettings === 'function' ? newSettings(currentUser.settings) : { ...currentUser.settings, ...newSettings };
    const updatedUser = { ...currentUser, settings: updatedSettings };
    setCurrentUser(updatedUser);
  };
  
  // FIX: Updated updateUser to handle both the list of all users and the current user.
  const updateUser = useCallback((updatedUser: User) => {
    setUsers(prevUsers => prevUsers.map(u => u.id === updatedUser.id ? updatedUser : u));
    if (currentUser?.id === updatedUser.id) {
        setCurrentUser(updatedUser);
    }
  }, [setCurrentUser, currentUser, setUsers]);

  const selectedCoin = useMemo(() => {
    const defaultCoin = (DEFAULT_COINS.find(c => c.id === DEFAULT_COIN_ID) || DEFAULT_COINS[0]) as Coin;
    if (allCoins.length === 0) {
        return defaultCoin;
    }
    const coinId = currentUser?.settings?.selectedCoinId || DEFAULT_SETTINGS.selectedCoinId;
    return allCoins.find(c => c.id === coinId) || allCoins[0] || defaultCoin;
  }, [currentUser, allCoins]);

  const selectedPayoutCoin = useMemo(() => {
    if (currentUser?.settings.selectedPayoutCoinId === 'custom') {
        return {
            id: 'custom',
            name: `Custom (${currentUser.settings.customPayoutTokenTicker})`,
            ticker: currentUser.settings.customPayoutTokenTicker,
            network: currentUser.settings.customPayoutTokenNetwork,
            logo: '', // Placeholder for custom token logo
            apy: 0,
            compoundIntervalSeconds: 0,
        }
    }
    const defaultPayoutCoin = (PAYOUT_COINS.find(c => c.id === DEFAULT_PAYOUT_COIN_ID) || PAYOUT_COINS[0]) as PayoutCoin;
    if (allPayoutCoins.length === 0) {
        return defaultPayoutCoin;
    }
    const coinId = currentUser?.settings?.selectedPayoutCoinId || DEFAULT_PAYOUT_COIN_ID;
    return allPayoutCoins.find(c => c.id === coinId) || allPayoutCoins[0] || defaultPayoutCoin;
  }, [currentUser, allPayoutCoins]);

  const allStakingCoins = useMemo(() => allPayoutCoins.filter(c => c.apy > 0), [allPayoutCoins]);
  const validators = useMemo(() => VALIDATORS[selectedPayoutCoin?.id] || [], [selectedPayoutCoin]);
  
  useEffect(() => {
      if (validators.length > 0 && !validators.find(v => v.id === selectedValidatorId)) {
          setSelectedValidatorId(validators[0].id);
      }
  }, [validators, selectedValidatorId, setSelectedValidatorId]);

  // Hooks
  const { miningLogs, hashrate, acceptedShares, rejectedShares, isMining, isStarting, startMining, stopMining: originalStopMining, miningChartData } = useMinerManager();
  const { walletBalance, transactions, initiateAction, actionState, confirmAction, cancelAction, isActionLoading, receiveFunds } = useWalletManager(selectedPayoutCoin);
  const { stakedBalance, claimableRewards, stakedPositions, stake, unstake, claimRewards } = useStakingEngine(selectedPayoutCoin, addToast);

  // Effect to update user status based on mining activity
  useEffect(() => {
    if (!currentUser || currentUser.status === 'offline') {
        return;
    }

    const targetStatus: 'mining' | 'online' = isMining ? 'mining' : 'online';

    if (currentUser.status !== targetStatus) {
        const updatedUser = { ...currentUser, status: targetStatus };
        updateUser(updatedUser);
    }
  }, [isMining, currentUser, updateUser]);

  // Pool Stats
  const [poolStats, setPoolStats] = useState<PoolStats | null>(null);
  const [isPoolStatsLoading, setIsPoolStatsLoading] = useState(false);

  const refreshPoolStats = useCallback(async () => {
      if (!currentUser || !selectedCoin) return;
      setIsPoolStatsLoading(true);
      try {
        const ticker = selectedCoin.mineableTicker || selectedCoin.ticker;
        const stats = await fetchPoolStats(currentUser.settings.selectedPoolId, currentUser.settings.walletAddress, ticker);
        setPoolStats(stats);
      } catch (error) {
        console.error("Failed to fetch pool stats:", error);
        setPoolStats(null);
      } finally {
        setIsPoolStatsLoading(false);
      }
  }, [currentUser, selectedCoin]);

  useEffect(() => {
    if (currentUser && isMining) {
      refreshPoolStats();
      const interval = setInterval(refreshPoolStats, 30000);
      return () => clearInterval(interval);
    }
  }, [currentUser, isMining, refreshPoolStats]);

  const handleStartMining = async () => {
      if (!currentUser) return false;
      const { minerPaths, selectedMinerPathId, selectedServerUrl, walletAddress, workerName, selectedPoolId, overclockProfiles, selectedOverclockProfileId } = currentUser.settings;
      const selectedMiner = minerPaths.find(p => p.id === selectedMinerPathId);

      if (!walletAddress) {
          addToast('Please set your payout wallet address in the Settings page.', 'error');
          return false;
      }
      if (!selectedMiner?.path || !selectedServerUrl) {
          addToast('Missing configuration. Check pool and miner path in settings.', 'error');
          return false;
      }
      
      const selectedProfile = overclockProfiles.find(p => p.id === selectedOverclockProfileId);
      if (selectedProfile) {
          const success = await backendAPI.applyOverclock(selectedProfile);
          if (success) {
              addToast(`Applied overclock profile: ${selectedProfile.name}`, 'info');
          } else {
              addToast(`Failed to apply overclock profile: ${selectedProfile.name}`, 'error');
          }
      }

      let walletArgument = walletAddress;
      if (selectedPoolId === 'unmineable') {
        const payoutTicker = selectedPayoutCoin.id === 'custom' 
            ? currentUser.settings.customPayoutTokenTicker.toUpperCase()
            : selectedPayoutCoin.ticker.toUpperCase();
        walletArgument = `${payoutTicker}:${walletAddress}`;
      }
      
      let command = selectedCoin.commandLineArgs
          .replace('{POOL_URL}', selectedServerUrl)
          .replace('{WALLET}', walletArgument)
          .replace('{WORKER_NAME}', workerName);
      
      return await startMining(selectedMiner.path, command);
  };
  
  const handleStopMining = async () => {
    if (currentUser?.settings.selectedOverclockProfileId) {
        await backendAPI.resetOverclock();
        addToast('Resetting overclock settings to default.', 'info');
    }
    await originalStopMining();
  };

  const handleWalletSetupComplete = (wallet: Wallet) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, wallet };
    updateUser(updatedUser);
  };

  // Render Logic
  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} onForceLogin={handleForceLogin} />;
  }
  
  if (currentUser && !currentUser.wallet) {
    return <WalletSetupPage onSetupComplete={handleWalletSetupComplete} />;
  }

  // FIX: Added 'users' and 'emulators' cases to the view renderer.
  const renderView = () => {
    switch (activeView) {
      case 'wallet': return <WalletPage />;
      case 'staking': return <StakingPage />;
      case 'settings': return <SettingsPage />;
      case 'referrals': return <ReferralPage />;
      case 'guide': return <SetupGuidePage />;
      case 'roadmap': return <RoadmapPage />;
      case 'users': return <UsersPage />;
      case 'emulators': return <EmulatorsPage />;
      case 'dashboard':
      default:
        return <Dashboard />;
    }
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      updateUser,
      // FIX: Added users and setUsers to the context provider value.
      users,
      setUsers,
      settings: currentUser.settings,
      setSettings,
      activeView,
      setActiveView,
      
      allCoins,
      selectedCoin,
      allPayoutCoins,
      selectedPayoutCoin,
      allStakingCoins,
      
      isMining,
      isStarting,
      hashrate,
      miningChartData,
      acceptedShares,
      rejectedShares,
      miningLogs,
      startMining: handleStartMining,
      stopMining: handleStopMining,
      
      poolStats,
      isPoolStatsLoading,
      refreshPoolStats,
      
      walletBalance,
      transactions,
      initiateAction,
      actionState,
      confirmAction,
      cancelAction,
      isActionLoading,
      receiveFunds,

      stakedBalance,
      claimableRewards,
      stakedPositions,
      stake,
      unstake,
      claimRewards,
      validators,
      selectedValidatorId,
      setSelectedValidatorId,

      payoutCoin: selectedPayoutCoin,
    }}>
      <div className={`flex h-screen font-sans bg-light-bg dark:bg-dark-bg text-light-text dark:text-dark-text ${currentUser.settings.theme}`}>
        <Sidebar activeView={activeView} setActiveView={setActiveView} />
        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
            {renderView()}
        </main>
      </div>
      <ActionConfirmationModal />
      {isUpdateDownloaded && <UpdateNotification onRestart={restartApp} />}
    </AppContext.Provider>
  );
}

const App: React.FC = () => {
    return (
        <ToastProvider>
            <AppContent />
        </ToastProvider>
    )
}

export default App;
