
import { ReactNode } from "react";

// FIX: Added Wallet interface for wallet management.
export interface Wallet {
  mnemonic: string;
  address: string;
}

// FIX: Added Transaction interface for transaction history.
export interface Transaction {
  id: string;
  type: 'send' | 'receive' | 'deposit';
  status: 'completed' | 'confirming' | 'failed';
  amount: number;
  fee?: number;
  address?: string; // For send transactions
  hash?: string;
  timestamp: string;
}

export interface Coin {
  id: string;
  name: string;
  ticker: string;
  network: string;
  logo: string;
  algorithm: string;
  commandLineArgs: string;
  recommendedDevice: 'CPU' | 'GPU';
  mineableTicker?: string; // Ticker to use for finding pools (e.g., ETC for SHIB)
  price?: number;
  blockTime?: number;
  blockReward?: number;
  networkHashrate?: number; // in MH/s
}

export interface PayoutCoin {
  id: string;
  name: string;
  ticker: string;
  network: string;
  logo: string;
  apy: number;
  compoundIntervalSeconds: number;
  price?: number;
}

export interface MiningPoolServer {
  region: string;
  url: string;
  type: 'Pool' | 'Solo';
}

export interface MiningPool {
  id: string;
  name: string;
  logo: string;
  serversByCoin: {
    [coinTicker: string]: MiningPoolServer[];
  };
}

export enum MiningDevice {
    CPU = 'CPU',
    GPU = 'GPU',
}

export enum MiningIntensity {
    Low = 'Low',
    Medium = 'Medium',
    High = 'High',
}

export interface MinerPath {
    id: string;
    name: string;
    path: string;
}

export interface OverclockProfile {
  id: string;
  name: string;
  coreClockOffset: number; // in MHz
  memoryClockOffset: number; // in MHz
  powerLimit: number; // in %
  fanSpeed: number; // in %
}

export interface AppSettings {
    selectedCoinId: string;
    selectedPayoutCoinId: string;
    walletAddress: string;
    selectedPoolId: string;
    selectedServerUrl: string;
    workerName: string;
    theme: 'light' | 'dark';
    device: MiningDevice;
    intensity: MiningIntensity;
    backgroundMining: boolean;
    minerPaths: MinerPath[];
    selectedMinerPathId: string | null;
    selectedStakingCoinId?: string;
    customPayoutTokenAddress: string;
    customPayoutTokenTicker: string;
    customPayoutTokenNetwork: string;
    overclockProfiles: OverclockProfile[];
    selectedOverclockProfileId: string | null;
}

export interface User {
    id: string;
    username: string;
    email: string;
    password?: string;
    role: 'admin' | 'user';
    status: 'online' | 'offline' | 'mining';
    lastSeen: string | null;
    settings: AppSettings;
    // FIX: Added wallet property to support integrated wallet features.
    wallet: Wallet | null;
}

export interface Validator {
  id: string;
  name: string;
  logo: string;
  commission: number;
  votingPower: number;
}

export interface ChartDataPoint {
  time: string;
  hashrate: number;
}

export enum LogLevel {
  INFO,
  WARN,
  ERROR,
  SUCCESS,
  RAW,
}

export interface LogEntry {
  timestamp: string;
  message: string;
  level: LogLevel;
}

export type ToastType = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: string;
  message: string;
  type: ToastType;
  link?: string;
}

export interface MarketData {
  price?: number;
  networkHashrate?: number;
}

export interface StakedPosition {
  validatorId: string;
  amount: number;
  rewards: number;
  stakedAt: string; // ISO date string
}

export interface PoolStats {
  hashrate: number; // Current hashrate reported by the pool in H/s
  unpaidBalance: number; // In the coin's main unit
  workersOnline: number;
  lastShare: number | null; // timestamp
}

// FIX: Moved ViewType here from App.tsx to avoid circular dependencies.
export type ViewType = 'dashboard' | 'wallet' | 'staking' | 'settings' | 'referrals' | 'guide' | 'roadmap' | 'users' | 'emulators';

// --- Emulator Types ---
export interface EmulatorDevice {
  id: string;
  type: 'ASIC' | 'GPU' | 'FPGA';
  name: string;
  baseHashrate: number; // in MH/s
  powerDraw: number; // in Watts
  algorithm: string;
}

export interface EmulatorConfig {
  devices: EmulatorDevice[];
  difficulty: number;
  devFee?: number; // percentage
}

export interface DeviceStats {
  id: string;
  name: string;
  type: 'ASIC' | 'GPU' | 'FPGA';
  hashrate: number;
  temperature: number;
  fanSpeed: number;
  power: number;
  acceptedShares: number;
  rejectedShares: number;
}

export interface EmulatorStatusUpdate {
  totalHashrate: number;
  totalPower: number;
  uptime: number; // seconds
  acceptedShares: number;
// FIX: Corrected typo 'aync' to 'number'.
  rejectedShares: number;
  devices: DeviceStats[];
  lastShareTime?: number; // timestamp
}

export type EmulatorLog = {
    timestamp: string;
    content: string;
    type: 'STATUS' | 'SHARE_FOUND' | 'ERROR' | 'DEV_FEE' | 'INFO';
};

export interface BfgminerInstance {
    id: string;
    status: 'running' | 'stopped';
    config: EmulatorConfig;
    stats: EmulatorStatusUpdate | null;
}