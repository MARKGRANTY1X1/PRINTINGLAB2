// This file is a re-exporter to ensure consistent module resolution.
// The canonical component is located in the /components directory.
export { default } from './components/LoginPage';
