
import React, { createContext } from 'react';
import {
  User, AppSettings, Coin, PayoutCoin, ChartDataPoint, LogEntry,
  Transaction, StakedPosition, Validator, PoolStats, ViewType
} from '../types';

// Defines the shape for the 'send' action details to ensure type safety
interface SendActionDetails {
  address: string;
  amount: number;
  fee: number;
}

// Defines the complete shape of the global application context
export interface AppContextType {
  currentUser: User;
  updateUser: (user: User) => void;
  // FIX: Added users and setUsers to the context type.
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  settings: AppSettings;
  setSettings: (newSettings: Partial<AppSettings> | ((prev: AppSettings) => AppSettings)) => void;
  activeView: ViewType;
  setActiveView: React.Dispatch<React.SetStateAction<ViewType>>;

  allCoins: Coin[];
  selectedCoin: Coin;
  allPayoutCoins: PayoutCoin[];
  selectedPayoutCoin: PayoutCoin;
  allStakingCoins: PayoutCoin[];

  isMining: boolean;
  isStarting: boolean;
  hashrate: number;
  miningChartData: ChartDataPoint[];
  acceptedShares: number;
  rejectedShares: number;
  miningLogs: LogEntry[];
  startMining: () => Promise<boolean>;
  stopMining: () => Promise<void>;

  poolStats: PoolStats | null;
  isPoolStatsLoading: boolean;
  refreshPoolStats: () => Promise<void>;

  walletBalance: number;
  transactions: Transaction[];
  initiateAction: (type: 'send', details: SendActionDetails) => void;
  actionState: { isOpen: boolean; type: 'send' | null; details: Partial<SendActionDetails> };
  confirmAction: () => Promise<void>;
  cancelAction: () => void;
  isActionLoading: boolean;
  receiveFunds: (amount: number) => Promise<void>;

  stakedBalance: number;
  claimableRewards: number;
  stakedPositions: StakedPosition[];
  stake: (amount: number, validatorId: string) => Promise<void>;
  unstake: (amount: number, validatorId: string) => Promise<void>;
  claimRewards: (validatorId: string) => Promise<void>;
  validators: Validator[];
  selectedValidatorId: string | null;
  setSelectedValidatorId: React.Dispatch<React.SetStateAction<string | null>>;

  payoutCoin: PayoutCoin;
}


// FIX: Moved AppContext to its own file to resolve circular dependencies
// that were causing a white screen issue. The context is now imported from
// here by all consumer components and the main App.tsx provider.
//
// Replaced `any` with the strict `AppContextType` for full type safety.
// `null!` is used because the provider is guaranteed to be available
// for all consumers, preventing the need for null checks in every component.
export const AppContext = createContext<AppContextType>(null!);