
// This file is no longer used. It was part of a Progressive Web App (PWA) setup
// that is not needed for a native Electron desktop application.
// This file can be safely deleted.
